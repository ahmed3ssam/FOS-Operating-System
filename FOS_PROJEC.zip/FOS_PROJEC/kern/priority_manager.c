#include <inc/stdio.h>
#include <kern/priority_manager.h>
#include <inc/assert.h>
#include <kern/helpers.h>
#include <kern/user_environment.h>

void set_program_priority(struct Env* env, int priority)
{
	//TODO: [PROJECT 2022 - BONUS4] Change WS Size according to Program Priority�

	panic("This function is not implemented yet\n");

}
